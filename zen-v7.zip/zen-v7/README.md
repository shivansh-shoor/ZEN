# Zen V7 — 3ft Wheeled Humanoid Robot

A 36-inch personal assistant robot with a wheeled base and humanoid upper body, controlled over Wi-Fi via a browser-based dashboard.

![Status: Active](https://img.shields.io/badge/status-active-00e68a?style=flat-square)
![Budget](https://img.shields.io/badge/budget-%E2%82%B93%2C500-green?style=flat-square)
![License: MIT](https://img.shields.io/badge/license-MIT-blue?style=flat-square)

---

## Overview

Zen V7 uses a **differential drive base** (2 DC motors + caster) for stable locomotion, paired with a **humanoid torso** (PVC spine, 2-DOF gesture arms, pan/tilt camera head) for natural interaction and eye-level telepresence.

The entire system runs on a single **ESP32-CAM** — it streams live video, serves the control dashboard, and drives all motors and servos.

**Total build cost: ~₹3,500 ($42 USD)** — sourced from Lajpat Rai Market, Robocraze, and MakerBazar (Delhi NCR, 2025 pricing).

---

## Hardware

| Component | Qty | Est. Cost (INR) |
|---|---|---|
| ESP32-CAM + FTDI Programmer | 1 | ₹550 |
| 12V DC Gear Motors (100 RPM) | 2 | ₹350 |
| L298N Motor Driver | 1 | ₹150 |
| MG996R Metal Gear Servos | 2 | ₹450 |
| SG90 Micro Servos | 2 | ₹180 |
| 18650 3S Battery Pack (11.1V) | 1 | ₹600 |
| LM2596 Buck Converter (12V→5V) | 1 | ₹120 |
| PVC Pipe 1.5" + T-Joints + Flange | — | ₹300 |
| 12" Circular MDF Base | 1 | ₹250 |
| Wheels + Caster Wheel | 3 | ₹250 |
| Jumper Wires, Zip Ties, Screws | — | ₹300 |
| **TOTAL** | | **~₹3,500** |

See [hardware/wiring-diagram.txt](hardware/wiring-diagram.txt) for pin connections.

---

## Software Architecture

```
┌─────────────────────────────────────┐
│         Browser (Phone / PC)        │
│  ┌───────────────────────────────┐  │
│  │     index.html Dashboard      │  │
│  │  Joystick · Sliders · Video  │  │
│  └───────────┬───────────────────┘  │
│              │ HTTP GET             │
└──────────────┼──────────────────────┘
               │ Wi-Fi
┌──────────────┼──────────────────────┐
│         ESP32-CAM                   │
│  ┌───────────┴───────────────────┐  │
│  │        zen_v7.ino             │  │
│  │  Web Server · MJPEG Stream    │  │
│  │  Motor PWM · Servo Control    │  │
│  └───┬────┬────┬────┬───────────┘  │
│      │    │    │    │              │
│   L298N Pan Tilt L-Arm R-Arm      │
│    │  │  SG90 SG90 MG996 MG996    │
│   M1  M2                            │
└─────────────────────────────────────┘
```

**Single-chip design.** The ESP32-CAM handles everything: video encoding, HTTP server, motor PWM, and servo signals. No secondary microcontroller needed.

---

## Wiring

| ESP32-CAM Pin | Connected To |
|---|---|
| GPIO 12 | L298N ENA (Left motor speed) |
| GPIO 13 | L298N IN1 (Left motor dir A) |
| GPIO 14 | L298N IN2 (Left motor dir B) |
| GPIO 2 | L298N ENB (Right motor speed) |
| GPIO 15 | L298N IN3 (Right motor dir A) |
| GPIO 0 | L298N IN4 (Right motor dir B) |
| GPIO 16 | SG90 Pan servo signal |
| GPIO 4 | SG90 Tilt servo signal |
| GPIO 5 | MG996R Left arm servo signal |
| GPIO 18 | MG996R Right arm servo signal |
| 5V | LM2596 output (servos + ESP32) |
| GND | Common ground with L298N + battery |

**Power path:** 3S Battery (11.1–12.6V) → L298N (motors) + LM2596 (5V for ESP32 + servos).

**Critical:** Solder a **1000µF capacitor** across the 5V and GND rails near the ESP32 to prevent brownout resets when servos move.

---

## Build Steps

### 1. Flash the Firmware

```bash
# Install Arduino IDE + ESP32 board package
# Board: "AI Thinker ESP32-CAM"
# Upload speed: 115200

# Flash firmware
arduino-cli compile --fqbn esp32:esp32:esp32cam firmware/zen_v7/zen_v7.ino --output-dir build/
arduino-cli upload --fqbn esp32:esp32:esp32cam --port /dev/ttyUSB0 build/zen_v7.ino.bin
```

### 2. Upload the Dashboard to SPIFFS

```bash
# Install esp32fs tool for Arduino IDE
# Or use mkspiffs / esptool manually:

pip install mkspiffs
mkspiffs -c firmware/zen_v7/data -p 256 -b 4096 -s 1048576 spiffs.bin
esptool.py --chip esp32 --port /dev/ttyUSB0 write_spi_flash 0x3A0000 spiffs.bin
```

> In Arduino IDE: **Tools → ESP32 Sketch Data Upload** (after installing [esp32fs](https://github.com/me-no-dev/arduino-esp32fs-plugin)).

### 3. Create `secrets.h`

Create `firmware/zen_v7/secrets.h` (gitignored, never commit this):

```c
#define WIFI_SSID "YourNetworkName"
#define WIFI_PASS "YourPassword"
```

### 4. Power On

1. Flip the ESP32-CAM switch to ON
2. Wait ~10 seconds for it to connect to Wi-Fi
3. Open the Arduino Serial Monitor (115200 baud) — it will print the IP address
4. Open that IP in your phone or PC browser
5. Drive

---

## Control Dashboard

The web dashboard (`index.html`) provides:

- **Live MJPEG video** from the ESP32-CAM
- **Virtual joystick** (touch + mouse) for differential drive
- **Keyboard control** (WASD / Arrow keys on desktop)
- **Speed slider** (10–100%)
- **Head pan/tilt** sliders (SG90 servos, 0°–180°)
- **Arm position** sliders (MG996R servos, 0°–180°)
- **6 preset animations** (Rest, Wave, Alert, Scan, Nod, Reach)
- **Emergency Stop** button
- **Motor output** visualization (bidirectional bars)
- **Settings panel** for changing IP/port at runtime

No app install needed — works in any modern browser.

---

## Sprints

| Sprint | What | Status |
|---|---|---|
| 1 | Drive base (motors + caster + L298N) | Complete |
| 2 | PVC spine + shoulders | Complete |
| 3 | Gesture arms (MG996R servos) | Complete |
| 4 | Pan/tilt head (SG90 + ESP32-CAM) | Complete |
| 5 | Electronics wiring + firmware + dashboard | Complete |

---

## Safety Notes

- **Brownout fix:** 1000µF capacitor across 5V/GND near ESP32. Non-negotiable.
- **Center of gravity:** Battery stays on the base. Never on top.
- **ESP32-CAM cooling:** Leave the chip exposed. Do not seal in plastic.
- **E-Stop:** Always accessible. Dashboard button + future physical button.
- **Servo current:** MG996R stall current can exceed 1.5A each. LM2596 rated for 3A max — don't move both arms at full speed simultaneously for long.

---

## Future Upgrades

- [ ] ROS2 integration via micro-ROS on ESP32
- [ ] Add ultrasonic sensor (HC-SR04) for obstacle avoidance
- [ ] 3D-printed shell replacing PVC frame
- [ ] AI voice assistant (Whisper + TTS on companion RPi)
- [ ] Head-tracking mode (camera follows face)
- [ ] Physical E-Stop button on the chassis

---

## License

MIT — see [LICENSE](LICENSE).
