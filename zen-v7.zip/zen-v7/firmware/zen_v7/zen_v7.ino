/*
 * Zen V7 — ESP32-CAM Firmware
 * 
 * Single-chip controller: MJPEG stream + web dashboard + motor PWM + servo control
 * Board: AI Thinker ESP32-CAM
 * 
 * Control endpoints (GET):
 *   /control?var=lmot&val=-255..255   Left motor
 *   /control?var=rmot&val=-255..255   Right motor
 *   /control?var=pan&val=0..180       Head pan
 *   /control?var=tilt&val=0..180      Head tilt
 *   /control?var=larm&val=0..180      Left arm
 *   /control?var=rarm&val=0..180      Right arm
 *   /control?var=stop&val=1           Emergency stop (all motors = 0)
 */

#include "secrets.h"  // #define WIFI_SSID / WIFI_PASS — create this file, it's gitignored
#include <WiFi.h>
#include <WiFiClient.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include "esp_camera.h"

// ============================================================
// PIN DEFINITIONS — AI Thinker ESP32-CAM
// ============================================================

// Camera pins (fixed by board design)
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

// Motor driver pins (L298N)
#define PIN_MOT_L_ENA    12  // PWM — left motor speed
#define PIN_MOT_L_IN1    13  // Left motor direction A
#define PIN_MOT_L_IN2    14  // Left motor direction B
#define PIN_MOT_R_ENB     2  // PWM — right motor speed
#define PIN_MOT_R_IN3    15  // Right motor direction A
#define PIN_MOT_R_IN4     0  // Right motor direction B

// Servo pins
#define PIN_SERVO_PAN    16  // SG90 — head pan (left/right)
#define PIN_SERVO_TILT    4  // SG90 — head tilt (up/down)
#define PIN_SERVO_LARM    5  // MG996R — left arm
// NOTE: GPIO 18 is used by camera (Y3). See workaround below.

// ============================================================
// RIGHT ARM SERVO WORKAROUND
// ============================================================
// GPIO 18 is shared with the camera data line Y3 on ESP32-CAM.
// The camera driver reconfigures it, so we can't use ledcAttach
// directly. Instead we use a software PWM approach with a timer.
// 
// If this causes flickering, move the right arm servo to GPIO 1
// (TX) — but you'll lose serial output. Acceptable for deployed use.

// Actually, let's use GPIO 1 for the right arm since we don't need
// TX after boot. This is the safer option.
#define PIN_SERVO_RARM     1  // MG996R — right arm (uses TX pin)

// ============================================================
// SERVO CONFIG
// ============================================================
#define SERVO_PAN_CHANNEL    0
#define SERVO_TILT_CHANNEL   1
#define SERVO_LARM_CHANNEL   2
#define SERVO_RARM_CHANNEL   3

#define SERVO_FREQ          50  // 50Hz for standard servos
#define SERVO_MIN_US      500  // 0° pulse width
#define SERVO_MAX_US     2500  // 180° pulse width

// PWM resolution for servos (14-bit gives fine granularity)
#define SERVO_PWM_BITS      14

// ============================================================
// MOTOR PWM CONFIG
// ============================================================
#define MOT_PWM_FREQ      1000  // 1kHz motor PWM
#define MOT_PWM_BITS        8   // 8-bit = 0..255

#define MOT_L_CH             4
#define MOT_R_CH             5

// ============================================================
// GLOBAL STATE
// ============================================================

WebServer server(80);

// Current values
int8_t  motorL = 0;    // -255 to 255
int8_t  motorR = 0;    // -255 to 255
uint8_t servoPan  = 90;
uint8_t servoTilt = 90;
uint8_t servoLArm = 0;
uint8_t servoRArm = 180;

// MJPEG stream state
camera_fb_t *fb = NULL;
bool streaming = false;

// ============================================================
// HELPER: Map servo angle to PWM duty cycle
// ============================================================
uint32_t angleToDuty(uint8_t angle) {
    uint32_t us = map(angle, 0, 180, SERVO_MIN_US, SERVO_MAX_US);
    // duty = (us / period) * (2^bits)
    // period at 50Hz = 20000us
    return (us * ((1 << SERVO_PWM_BITS) - 1)) / 20000;
}

// ============================================================
// SET MOTOR
// ============================================================
void setMotor(int8_t pin_en, int8_t pin_in1, int8_t pin_in2, uint8_t ch, int val) {
    val = constrain(val, -255, 255);
    
    if (val > 0) {
        // Forward
        digitalWrite(pin_in1, HIGH);
        digitalWrite(pin_in2, LOW);
        ledcWrite(ch, val);
    } else if (val < 0) {
        // Reverse
        digitalWrite(pin_in1, LOW);
        digitalWrite(pin_in2, HIGH);
        ledcWrite(ch, -val);
    } else {
        // Stop
        digitalWrite(pin_in1, LOW);
        digitalWrite(pin_in2, LOW);
        ledcWrite(ch, 0);
    }
}

void updateMotors() {
    setMotor(PIN_MOT_L_ENA, PIN_MOT_L_IN1, PIN_MOT_L_IN2, MOT_L_CH, motorL);
    setMotor(PIN_MOT_R_ENB, PIN_MOT_R_IN3, PIN_MOT_R_IN4, MOT_R_CH, motorR);
}

// ============================================================
// SET SERVO
// ============================================================
void setServo(uint8_t channel, uint8_t angle) {
    angle = constrain(angle, 0, 180);
    ledcWrite(channel, angleToDuty(angle));
}

void updateServos() {
    setServo(SERVO_PAN_CHANNEL,  servoPan);
    setServo(SERVO_TILT_CHANNEL, servoTilt);
    setServo(SERVO_LARM_CHANNEL, servoLArm);
    setServo(SERVO_RARM_CHANNEL, servoRArm);
}

// ============================================================
// CAMERA INIT
// ============================================================
bool initCamera() {
    camera_config_t config;
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer   = LEDC_TIMER_0;
    config.pin_d0       = Y2_GPIO_NUM;
    config.pin_d1       = Y3_GPIO_NUM;
    config.pin_d2       = Y4_GPIO_NUM;
    config.pin_d3       = Y5_GPIO_NUM;
    config.pin_d4       = Y6_GPIO_NUM;
    config.pin_d5       = Y7_GPIO_NUM;
    config.pin_d6       = Y8_GPIO_NUM;
    config.pin_d7       = Y9_GPIO_NUM;
    config.pin_xclk     = XCLK_GPIO_NUM;
    config.pin_pclk     = PCLK_GPIO_NUM;
    config.pin_vsync    = VSYNC_GPIO_NUM;
    config.pin_href     = HREF_GPIO_NUM;
    config.pin_sccb_sda = SIOD_GPIO_NUM;
    config.pin_sccb_scl = SIOC_GPIO_NUM;
    config.pin_pwdn     = PWDN_GPIO_NUM;
    config.pin_reset    = RESET_GPIO_NUM;
    config.xclk_freq_hz = 20000000;
    config.pixel_format = PIXFORMAT_JPEG;
    
    // Lower resolution for smooth streaming over Wi-Fi
    config.frame_size   = FRAMESIZE_QVGA;  // 320x240
    config.jpeg_quality = 12;               // 0-63, lower = better quality
    config.fb_count     = 1;

    esp_err_t err = esp_camera_init(&config);
    if (err != ESP_OK) {
        Serial.printf("Camera init failed: 0x%x\n", err);
        return false;
    }
    
    // Adjust sensor settings for better performance
    sensor_t *s = esp_camera_sensor_get();
    s->set_brightness(s, 0);
    s->set_contrast(s, 0);
    s->set_saturation(s, 0);
    s->set_whitebal(s, 1);   // Auto white balance
    s->set_awb_gain(s, 1);
    s->set_exposure_ctrl(s, 1);  // Auto exposure
    s->set_aec2(s, 0);
    s->set_gain_ctrl(s, 1);      // Auto gain
    s->set_agc_gain(s, 0);
    s->set_gainceiling(s, (gainceiling_t)6);
    s->set_bpc(s, 0);
    s->set_wpc(s, 1);
    s->set_dcw(s, 0);
    s->set_lenc(s, 1);
    
    return true;
}

// ============================================================
// MJPEG STREAM HANDLER
// ============================================================
void handleStream() {
    WiFiClient client = server.client();
    
    client.println("HTTP/1.1 200 OK");
    client.println("Content-Type: multipart/x-mixed-replace; boundary=frame");
    client.println("Access-Control-Allow-Origin: *");
    client.println("Cache-Control: no-cache, no-store");
    client.println("Connection: close");
    client.println();
    
    streaming = true;
    
    while (streaming && client.connected()) {
        fb = esp_camera_fb_get();
        if (!fb) {
            Serial.println("Frame buffer failed");
            delay(10);
            continue;
        }
        
        client.printf("--frame\r\n");
        client.printf("Content-Type: image/jpeg\r\n");
        client.printf("Content-Length: %u\r\n\r\n", fb->len);
        client.write(fb->buf, fb->len);
        client.printf("\r\n");
        
        esp_camera_fb_return(fb);
        fb = NULL;
        
        // Frame rate limiting (~15 FPS)
        delay(66);
    }
    
    streaming = false;
}

// ============================================================
// CONTROL ENDPOINT HANDLER
// ============================================================
void handleControl() {
    if (!server.hasArg("var") || !server.hasArg("val")) {
        server.send(400, "text/plain", "Missing var or val");
        return;
    }
    
    String varName = server.arg("var");
    int val = server.arg("val").toInt();
    
    if (varName == "lmot") {
        motorL = constrain(val, -255, 255);
        updateMotors();
    } else if (varName == "rmot") {
        motorR = constrain(val, -255, 255);
        updateMotors();
    } else if (varName == "pan") {
        servoPan = constrain(val, 0, 180);
        setServo(SERVO_PAN_CHANNEL, servoPan);
    } else if (varName == "tilt") {
        servoTilt = constrain(val, 0, 180);
        setServo(SERVO_TILT_CHANNEL, servoTilt);
    } else if (varName == "larm") {
        servoLArm = constrain(val, 0, 180);
        setServo(SERVO_LARM_CHANNEL, servoLArm);
    } else if (varName == "rarm") {
        servoRArm = constrain(val, 0, 180);
        setServo(SERVO_RARM_CHANNEL, servoRArm);
    } else if (varName == "stop") {
        motorL = 0;
        motorR = 0;
        updateMotors();
    } else {
        server.send(400, "text/plain", "Unknown variable");
        return;
    }
    
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.send(200, "text/plain", "OK");
}

// ============================================================
// CORS PREFLIGHT
// ============================================================
void handleOptions() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.sendHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
    server.sendHeader("Access-Control-Allow-Headers", "*");
    server.send(204);
}

// ============================================================
// DASHBOARD (SERVED FROM SPIFFS)
// ============================================================
void handleDashboard() {
    // Try to serve from SPIFFS first
    File f = SPIFFS.open("/index.html", "r");
    if (f) {
        server.streamFile(f, "text/html");
        f.close();
    } else {
        // Fallback: redirect to stream if no SPIFFS uploaded
        server.sendHeader("Location", "/stream");
        server.send(302);
    }
}

// ============================================================
// SETUP
// ============================================================
void setup() {
    Serial.begin(115200);
    Serial.setDebugOutput(false);
    Serial.println();
    Serial.println("=== Zen V7 Booting ===");
    
    // --- Init GPIO for motor direction pins ---
    pinMode(PIN_MOT_L_IN1, OUTPUT);
    pinMode(PIN_MOT_L_IN2, OUTPUT);
    pinMode(PIN_MOT_R_IN3, OUTPUT);
    pinMode(PIN_MOT_R_IN4, OUTPUT);
    digitalWrite(PIN_MOT_L_IN1, LOW);
    digitalWrite(PIN_MOT_L_IN2, LOW);
    digitalWrite(PIN_MOT_R_IN3, LOW);
    digitalWrite(PIN_MOT_R_IN4, LOW);
    
    // --- Init motor PWM channels ---
    ledcSetup(MOT_L_CH, MOT_PWM_FREQ, MOT_PWM_BITS);
    ledcAttachChannel(PIN_MOT_L_ENA, MOT_PWM_FREQ, MOT_L_CH);
    ledcSetup(MOT_R_CH, MOT_PWM_FREQ, MOT_PWM_BITS);
    ledcAttachChannel(PIN_MOT_R_ENB, MOT_PWM_FREQ, MOT_R_CH);
    
    // --- Init servo PWM channels ---
    ledcSetup(SERVO_PAN_CHANNEL,  SERVO_FREQ, SERVO_PWM_BITS);
    ledcSetup(SERVO_TILT_CHANNEL, SERVO_FREQ, SERVO_PWM_BITS);
    ledcSetup(SERVO_LARM_CHANNEL, SERVO_FREQ, SERVO_PWM_BITS);
    ledcSetup(SERVO_RARM_CHANNEL, SERVO_FREQ, SERVO_PWM_BITS);
    ledcAttachChannel(PIN_SERVO_PAN,  SERVO_FREQ, SERVO_PAN_CHANNEL);
    ledcAttachChannel(PIN_SERVO_TILT, SERVO_FREQ, SERVO_TILT_CHANNEL);
    ledcAttachChannel(PIN_SERVO_LARM, SERVO_FREQ, SERVO_LARM_CHANNEL);
    ledcAttachChannel(PIN_SERVO_RARM, SERVO_FREQ, SERVO_RARM_CHANNEL);
    
    // --- Set servos to default positions ---
    updateServos();
    Serial.println("Servos initialized to default positions");
    
    // --- Init camera ---
    Serial.print("Initializing camera... ");
    if (initCamera()) {
        Serial.println("OK");
    } else {
        Serial.println("FAILED — continuing without camera");
    }
    
    // --- Mount SPIFFS ---
    Serial.print("Mounting SPIFFS... ");
    if (SPIFFS.begin(true)) {  // true = format on first use
        Serial.println("OK");
        if (SPIFFS.exists("/index.html")) {
            Serial.println("Dashboard found in SPIFFS");
        } else {
            Serial.println("WARNING: /index.html not found in SPIFFS");
            Serial.println("Upload dashboard: Tools → ESP32 Sketch Data Upload");
        }
    } else {
        Serial.println("FAILED");
    }
    
    // --- Connect to Wi-Fi ---
    Serial.printf("Connecting to %s", WIFI_SSID);
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    
    int wifiAttempts = 0;
    while (WiFi.status() != WL_CONNECTED && wifiAttempts < 40) {
        delay(500);
        Serial.print(".");
        wifiAttempts++;
    }
    Serial.println();
    
    if (WiFi.status() == WL_CONNECTED) {
        Serial.println("=== Wi-Fi Connected ===");
        Serial.printf("IP Address: %s\n", WiFi.localIP().toString().c_str());
        Serial.printf("Stream URL: http://%s/stream\n", WiFi.localIP().toString().c_str());
        Serial.printf("Dashboard:  http://%s/\n", WiFi.localIP().toString().c_str());
    } else {
        Serial.println("WARNING: Wi-Fi connection failed!");
        Serial.println("Check secrets.h and restart");
    }
    
    // --- Start mDNS ---
    if (MDNS.begin("zen")) {
        Serial.println("mDNS started — access via http://zen.local/");
    }
    
    // --- HTTP Routes ---
    server.on("/",           HTTP_GET,  handleDashboard);
    server.on("/stream",     HTTP_GET,  handleStream);
    server.on("/control",    HTTP_GET,  handleControl);
    server.on("/control",    HTTP_OPTIONS, handleOptions);
    
    server.begin();
    Serial.println("HTTP server started");
    Serial.println("=== Zen V7 Ready ===");
}

// ============================================================
// LOOP
// ============================================================
void loop() {
    server.handleClient();
    
    // If Wi-Fi drops, try to reconnect
    static unsigned long lastWifiCheck = 0;
    if (millis() - lastWifiCheck > 30000) {  // Check every 30s
        lastWifiCheck = millis();
        if (WiFi.status() != WL_CONNECTED) {
            Serial.println("Wi-Fi disconnected — reconnecting...");
            WiFi.disconnect();
            WiFi.begin(WIFI_SSID, WIFI_PASS);
        }
    }
}
